def xtime(byte):
    """
    Perform multiplication by 2 in GF(2^8).
    """
    return ((byte << 1) ^ 0x1B) if (byte & 0x80) else (byte << 1)

def mix_columns(state):
    """
    Perform the MixColumns operation on the AES state.
    The state is a 1D array of 16 bytes.
    """
    for i in range(4):
        t = state[i * 4]
        tmp = state[i * 4] ^ state[i * 4 + 1] ^ state[i * 4 + 2] ^ state[i * 4 + 3]
        
        state[i * 4] ^= xtime(state[i * 4] ^ state[i * 4 + 1]) ^ tmp
        state[i * 4 + 1] ^= xtime(state[i * 4 + 1] ^ state[i * 4 + 2]) ^ tmp
        state[i * 4 + 2] ^= xtime(state[i * 4 + 2] ^ state[i * 4 + 3]) ^ tmp
        state[i * 4 + 3] ^= xtime(state[i * 4 + 3] ^ t) ^ tmp

    # Ensure bytes are in the range 0-255
    for i in range(16):
        state[i] &= 0xFF

# Example usage
if __name__ == "__main__":
    # Example state array (1D array of 16 bytes)
    state = [
        0x87, 0xF2, 0x4D, 0x97,
        0x6E, 0x4C, 0x90, 0xEC,
        0x46, 0xE7, 0x4A, 0xC3,
        0xA6, 0x8C, 0xD8, 0x95
    ]
    print("Original State:")
    print([hex(x) for x in state])

    mix_columns(state)

    print("\nState after MixColumns:")
    print([hex(x) for x in state])
