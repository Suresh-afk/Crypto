def pad(msg):
	msg_len_in_bits = (8*len(msg)) & 0xffffffffffffffff
	msg.append(0x80)

	while len(msg)%64 != 56:
		msg.append(0)

	msg += msg_len_in_bits.to_bytes(8, byteorder='little')
	
	return msg

if __name__ == "__main__":
    # Example input message
    message = bytearray(b"hi hello how are you")

    # Perform MD5 padding
    padded_message = pad(message)

    # Display the padded message as a hexadecimal string
    print("Padded Message:")
    print(padded_message.hex())
    