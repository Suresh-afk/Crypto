import random

# El-Gamal Helper Functions

def gcd(a, b):
    """Calculate greatest common divisor of a and b using Euclidean algorithm."""
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(a, m):
    """Return modular inverse of a under modulo m using Extended Euclidean algorithm."""
    m0, x0, x1 = m, 0, 1
    while a > 1:
        q = a // m
        a, m = m, a % m
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += m0
    return x1

def is_prime(n):
    """Check if a number is prime."""
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

# El-Gamal Key Generation using user input
def get_user_input_keys():
    """Prompt user to input El-Gamal public and private keys."""
    p = int(input("Enter prime number p: "))
    g = int(input("Enter generator g (primitive root modulo p): "))
    x = int(input("Enter private key x (1 < x < p-2): "))
    y = pow(g, x, p)  # Public key y = g^x % p
    return (p, g, y), (p, g, x)

# El-Gamal Signature Generation
def generate_signature(message, private_key):
    """Generate El-Gamal signature on the message."""
    p, g, x = private_key  # Unpack private key
    k = random.randint(1, p - 2)  # Random integer k (1 < k < p-2)
    r = pow(g, k, p)  # r = g^k % p
    s = ((message - x * r) * mod_inverse(k, p - 1)) % (p - 1)  # s = (message - x * r) * k^-1 % (p - 1)
    return r, s

# El-Gamal Signature Verification
def verify_signature(message, signature, public_key):
    """Verify El-Gamal signature."""
    p, g, y = public_key  # Unpack public key
    r, s = signature  # Unpack signature

    # Check if r and s are within valid range
    if r <= 0 or r >= p or s <= 0 or s >= p - 1:
        return False

    # Calculate v1 = g^message % p
    v1 = pow(g, message, p)
    
    # Calculate v2 = y^r * r^s % p
    v2 = (pow(y, r, p) * pow(r, s, p)) % p
    
    # If v1 == v2, the signature is valid
    return v1 == v2

# Simple Hash Function (sum of ASCII values mod p for simplicity)
def hash_message(message, p):
    """Simple hash function: sum of ASCII values mod p."""
    return sum(ord(char) for char in message) % p

# Example Usage
if __name__ == "__main__":
    # Get user input for El-Gamal keys
    public_key, private_key = get_user_input_keys()
    print("Public Key:", public_key)
    print("Private Key:", private_key)

    # Sign a message
    message = input("\nEnter the message to sign: ")
    message_hash = hash_message(message, public_key[0])
    signature = generate_signature(message_hash, private_key)
    print("\nSignature:", signature)

    # Verify the signature
    is_valid = verify_signature(message_hash, signature, public_key)
    print("\nSignature valid?", is_valid)