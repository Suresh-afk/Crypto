import random

def gcd(a, b):
    """
    Compute the greatest common divisor of a and b.
    """
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(a, m):
    """
    Compute the modular inverse of a modulo m using the Extended Euclidean Algorithm.
    """
    m0, x0, x1 = m, 0, 1
    while a > 1:
        q = a // m
        a, m = m, a % m
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += m0
    return x1

def get_user_input():
    """
    Prompt the user to input the required parameters for DSS keys.
    """
    p = int(input("Enter prime number p: "))
    q = int(input("Enter prime number q (should divide p-1): "))
    g = int(input("Enter generator g (mod p): "))
    x = int(input("Enter private key x (1 <= x <= q-1): "))
    
    return p, q, g, x

def sign(message, p, q, g, x):
    """
    Sign a message using the private key.
    """
    # Hash the message (use a simple hash for demonstration)
    h = sum(ord(char) for char in message) % q

    # Choose a random `k` in [1, q-1] such that gcd(k, q) = 1
    while True:
        k = random.randint(1, q - 1)
        if gcd(k, q) == 1:
            break

    # Compute r = (g^k mod p) mod q
    r = pow(g, k, p) % q

    # Compute s = (k^(-1) * (h + x * r)) mod q
    k_inv = mod_inverse(k, q)
    s = (k_inv * (h + x * r)) % q

    return r, s

def verify(message, r, s, p, q, g, y):
    """
    Verify a signature using the public key.
    """
    # Hash the message (use the same hash as in signing)
    h = sum(ord(char) for char in message) % q

    # Verify r and s are in the valid range
    if not (0 < r < q and 0 < s < q):
        return False

    # Compute w = s^(-1) mod q
    w = mod_inverse(s, q)

    # Compute u1 = (h * w) mod q and u2 = (r * w) mod q
    u1 = (h * w) % q
    u2 = (r * w) % q

    # Compute v = ((g^u1 * y^u2) mod p) mod q
    v = ((pow(g, u1, p) * pow(y, u2, p)) % p) % q

    # The signature is valid if v == r
    return v == r

# Example usage
if __name__ == "__main__":
    # Get user input for keys
    p, q, g, x = get_user_input()

    # Compute public key y = g^x mod p
    y = pow(g, x, p)

    public_key = (p, q, g, y)
    private_key = x

    print("\nPublic Key:", public_key)
    print("Private Key:", private_key)

    # Sign a message
    message = input("\nEnter the message to sign: ")
    r, s = sign(message, p, q, g, private_key)
    print("\nSignature (r, s):", (r, s))

    # Verify the signature
    is_valid = verify(message, r, s, p, q, g, y)
    print("\nSignature valid?", is_valid)
