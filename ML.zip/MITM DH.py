p = 17 # Prime number
g = 7 # Generator
X_a = 5 # Alice's private key
X_b = 4 # Bob's private key
X_DA = 4 # Darth's private key with Alice
X_DB = 8 # Darth's private key with Bob
Y_a = pow(g, X_a, p) # Alice's public key
Y_b = pow(g, X_b, p) # Bob's public key
Y_DA = pow(g, X_DA, p) # Darth's public key for Alice
Y_DB = pow(g, X_DB, p) # Darth's public key for Bob
print("Darth intercepts and modifies the public keys:")
print(f"Darth sends Y_DA ({Y_DA}) to Bob instead of Alice's Y_a({Y_a}).")
print(f"Darth sends Y_DB ({Y_DB}) to Alice instead of Bob's Y_b({Y_b}).")
K_DB = pow(Y_b, X_DB, p) # Shared key between Bob and Darth
print(f"Bob computes shared key with Darth (K_DB): {K_DB}")
K_DA = pow(Y_a, X_DA, p) # Shared key between Alice and Darthz
print(f"Alice computes shared key with Darth (K_DA): {K_DA}")
print("\nVerification:")
print(f"Darth's shared key with Alice (K_DA): {K_DA}")
print(f"Darth's shared key with Bob (K_DB): {K_DB}")
K_ab = pow(Y_b, X_a, p)
print(f"Original shared key between Alice and Bob (K_ab): {K_ab}")
print(f"Darth's key matches Alice and Bob's shared key: {K_DA == K_ab or K_DB == K_ab}")