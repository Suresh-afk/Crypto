def sha_padding(msg):
    """
    Perform SHA padding on the input message.
    Args:
        msg (bytearray): The input message as a bytearray.
    Returns:
        bytearray: The padded message.
    """
    # Calculate the original message length in bits
    msg_len_in_bits = (8 * len(msg)) & 0xFFFFFFFFFFFFFFFF

    # Append the '1' bit as 0x80
    msg.append(0x80)

    # Add zero bytes until the length is congruent to 56 modulo 64
    while len(msg) % 64 != 56:
        msg.append(0)

    # Append the original length as a 64-bit big-endian integer
    msg += msg_len_in_bits.to_bytes(8, byteorder='big')

    return msg

if __name__ == "__main__":
    # Example input message
    message = bytearray(b"hello")

    # Perform SHA padding
    padded_message = sha_padding(message)

    # Display the padded message as a hexadecimal string
    print("Padded Message:")
    print(padded_message.hex())
    