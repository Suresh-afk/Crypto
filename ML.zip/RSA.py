def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    phi_original = phi
    x0, x1 = 0, 1
    while e > 1:
        q = e // phi
        e, phi = phi, e % phi
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += phi_original
    return x1

def rsa_keygen():
    p = 61  # Small prime number
    q = 53  # Another small prime number
    n = p * q
    phi = (p - 1) * (q - 1)

    # Choose e such that gcd(e, phi) = 1
    e = 17  # Common choice for simplicity
    d = mod_inverse(e, phi)

    return (e, n), (d, n)

def rsa_encrypt(public_key, plaintext):
    e, n = public_key
    # Convert characters to ASCII and encrypt
    ciphertext = [pow(ord(char), e, n) for char in plaintext]
    return ciphertext

def rsa_decrypt(private_key, ciphertext):
    d, n = private_key
    # Decrypt each number and convert to characters
    plaintext = ''.join(chr(pow(char, d, n)) for char in ciphertext)
    return plaintext

# Example usage
if __name__ == "__main__":
    # Generate keys
    public_key, private_key = rsa_keygen()
    print("Public Key:", public_key)
    print("Private Key:", private_key)

    # Encrypt a message
    message = "Hi"
    print("Original Message:", message)
    ciphertext = rsa_encrypt(public_key, message)
    print("Encrypted Message:", ciphertext)

    # Decrypt the message
    decrypted_message = rsa_decrypt(private_key, ciphertext)
    print("Decrypted Message:", decrypted_message)
