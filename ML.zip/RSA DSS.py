import random

# RSA Helper Functions
def gcd(a, b):
    """Calculate greatest common divisor of a and b using Euclidean algorithm."""
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(a, m):
    """Return modular inverse of a under modulo m using Extended Euclidean algorithm."""
    m0, x0, x1 = m, 0, 1
    while a > 1:
        q = a // m
        a, m = m, a % m
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += m0
    return x1

# RSA Key Generation using user input
def get_user_input_keys():
    """Prompt user to input RSA public and private keys."""
    p = int(input("Enter prime number p: "))
    q = int(input("Enter prime number q: "))
    e = int(input("Enter public exponent e (1 < e < phi(n) and gcd(e, phi(n)) = 1): "))
    d = int(input("Enter private exponent d (1 < d < phi(n)): "))
    n = p * q
    return (n, e), (n, d)

# RSA Encryption/Decryption
def rsa_encrypt(message, public_key):
    """Encrypt the message using RSA public key (n, e)."""
    n, e = public_key
    return [pow(ord(char), e, n) for char in message]

def rsa_decrypt(ciphertext, private_key):
    """Decrypt the ciphertext using RSA private key (n, d)."""
    n, d = private_key
    return ''.join([chr(pow(char, d, n)) for char in ciphertext])

# Hashing Function (simple sum of ASCII values mod 256 for simplicity)
def hash_message(message):
    """Simple hash function: sum of ASCII values mod 256."""
    return sum(ord(char) for char in message) % 256

# Signature Generation
def generate_signature(message, private_key):
    """Generate a signature by encrypting the hashed message with the private key."""
    message_hash = hash_message(message)
    signature = rsa_encrypt(str(message_hash), private_key)
    return signature

# Signature Verification
def verify_signature(message, signature, public_key):
    """Verify the signature by decrypting with the public key and comparing with the message hash."""
    decrypted_signature = rsa_decrypt(signature, public_key)
    message_hash = hash_message(message)
    return decrypted_signature == str(message_hash)

# Example Usage
if __name__ == "__main__":
    # Get user input for RSA keys
    public_key, private_key = get_user_input_keys()
    print("Public Key:", public_key)
    print("Private Key:", private_key)

    # Sign a message
    message = input("\nEnter the message to sign: ")
    signature = generate_signature(message, private_key)
    print("\nSignature:", signature)

    # Verify the signature
    is_valid = verify_signature(message, signature, public_key)
    print("\nSignature valid?", is_valid)
